<?php
include '../koneksi.php';

if($_SERVER['REQUEST_METHOD'] !== 'PATCH'){
    header('Content-Type: application/json');
    http_response_code(400);
    $reply['error'] = 'PATCH method required';
    echo json_encode($reply);
    exit();
}
/**
 * Get input data PATCH
 */
$formData = [];
parse_str(file_get_contents('php://input'), $formData);

$kode_buku = $formData['kode_buku'] ?? '';
$isbn = $formData['isbn'] ?? 0;
$judul_buku = $formData['judul_buku'] ?? '';
$pengarang = $formData['pengarang'] ?? '';
$penerbit = $formData['penerbit'] ?? '';
$tahun_terbit = $formData['tahun_terbit'] ?? '';

/**
 * Validation int value
 */
$jumlahFilter = filter_var($isbn, FILTER_VALIDATE_INT);

/**
 * METHOD OK
 * Validation OK
 * Check if data is exist
 */
try{
    $queryCheck = "SELECT * FROM buku where isbn = :isbn";
    $statement = $connection->prepare($queryCheck);
    $statement->bindValue(':isbn', $isbn);
    $statement->execute();
    $row = $statement->rowCount();
    /**
     * Jika data tidak ditemukan
     * rowcount == 0
     */
    if($row === 0){
        $reply['error'] = 'Data tidak ditemukan ISBN '.$isbn;
        echo json_encode($reply);
        http_response_code(400);
        exit(0);
    }
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}

/**
 * Prepare query
 */
try{
    $fields = [];
    $query = "UPDATE buku SET kode_buku = :kode_buku, judul_buku = :judul_buku, pengarang = :pengarang, penerbit = :penerbit, tahun_terbit = :tahun_terbit 
WHERE isbn = :isbn";
    $statement = $connection->prepare($query);
    /**
     * Bind params
     */
    $statement->bindValue(":kode_buku", $kode_buku);
    $statement->bindValue(":isbn", $isbn, PDO::PARAM_INT);
    $statement->bindValue(":judul_buku", $judul_buku);
    $statement->bindValue(":pengarang", $pengarang);
    $statement->bindValue(":penerbit", $penerbit);
    $statement->bindValue(":tahun_terbit", $tahun_terbit);
    /**
     * Execute query
     */
    $isOk = $statement->execute();
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}
/**
 * If not OK, add error info
 * HTTP Status code 400: Bad request
 * @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#client_error_responses
 */
if(!$isOk){
    $reply['error'] = $statement->errorInfo();
    http_response_code(400);
}

/*
 * Get data
 */
$stmSelect = $connection->prepare("SELECT * FROM buku where isbn = :isbn");
$stmSelect->bindValue(':isbn', $isbn);
$stmSelect->execute();
$dataBuku = $stmSelect->fetch(PDO::FETCH_ASSOC);

/**
 * Show output to client
 */
$reply['status'] = $isOk;
echo json_encode($reply);