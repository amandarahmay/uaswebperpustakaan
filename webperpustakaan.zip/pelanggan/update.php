<?php
include '../koneksi.php';

if($_SERVER['REQUEST_METHOD'] !== 'PATCH'){
    header('Content-Type: application/json');
    http_response_code(400);
    $reply['error'] = 'PATCH method required';
    echo json_encode($reply);
    exit();
}
/**
 * Get input data PATCH
 */
$formData = [];
parse_str(file_get_contents('php://input'), $formData);

$id_pelanggan = $formData['id_pelanggan'] ?? 0;
$nama = $formData['nama'] ?? '';
$jenis_kelamin = $formData['jenis_kelamin'] ?? '';
$tanggal_lahir = $formData['tanggal_lahir'] ?? date('Y-m-d');
$telepon = $formData['telepon'] ?? 0;
$alamat = $formData['alamat'] ?? '';
$username = $formData['username'] ?? '';
$password = $formData['password'] ?? '';

/**
 * Validation int value
 */
$jumlahFilter = filter_var($id_pelanggan, $telepon, FILTER_VALIDATE_INT);

/**
 * METHOD OK
 * Validation OK
 * Check if data is exist
 */
try{
    $queryCheck = "SELECT * FROM pelanggan where id_pelanggan = :id_pelanggan";
    $statement = $connection->prepare($queryCheck);
    $statement->bindValue(':id_pelanggan', $id_pelanggan);
    $statement->execute();
    $row = $statement->rowCount();
    /**
     * Jika data tidak ditemukan
     * rowcount == 0
     */
    if($row === 0){
        $reply['error'] = 'Data tidak ditemukan ID Pelanggan '.$id_pelanggan;
        echo json_encode($reply);
        http_response_code(400);
        exit(0);
    }
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}

/**
 * Prepare query
 */
try{
    $fields = [];
    $query = "UPDATE pelanggan SET nama = :nama, jenis_kelamin = :jenis_kelamin, tanggal_lahir = :tanggal_lahir, telepon = :telepon, alamat = :alamat, username = :username, password = :password
WHERE id_pelanggan = :id_pelanggan";
    $statement = $connection->prepare($query);
    /**
     * Bind params
     */
    $statement->bindValue(":id_pelanggan", $id_pelanggan, PDO::PARAM_INT);
    $statement->bindValue(":nama", $nama);
    $statement->bindValue(":jenis_kelamin", $jenis_kelamin);
    $statement->bindValue(":tanggal_lahir", $tanggal_lahir);
    $statement->bindValue(":telepon", $telepon, PDO::PARAM_INT);
    $statement->bindValue(":alamat", $alamat);
    $statement->bindValue(":username", $username);
    $statement->bindValue(":password", $password);
    /**
     * Execute query
     */
    $isOk = $statement->execute();
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}
/**
 * If not OK, add error info
 * HTTP Status code 400: Bad request
 * @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#client_error_responses
 */
if(!$isOk){
    $reply['error'] = $statement->errorInfo();
    http_response_code(400);
}

/*
 * Get data
 */
$stmSelect = $connection->prepare("SELECT * FROM pelanggan where id_pelanggan = :id_pelanggan");
$stmSelect->bindValue(':id_pelanggan', $id_pelanggan);
$stmSelect->execute();
$dataBuku = $stmSelect->fetch(PDO::FETCH_ASSOC);

/**
 * Show output to client
 */
$reply['status'] = $isOk;
echo json_encode($reply);