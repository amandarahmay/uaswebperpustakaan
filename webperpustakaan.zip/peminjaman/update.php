<?php
include '../koneksi.php';

if($_SERVER['REQUEST_METHOD'] !== 'PATCH'){
    header('Content-Type: application/json');
    http_response_code(400);
    $reply['error'] = 'PATCH method required';
    echo json_encode($reply);
    exit();
}
/**
 * Get input data PATCH
 */
$formData = [];
parse_str(file_get_contents('php://input'), $formData);

$id_peminjaman = $formData['id_peminjaman'] ?? 0;
$id_pelanggan = $formData['id_pelanggan'] ?? 0;
$isbn = $formData['isbn'] ?? 0;
$judul_buku = $formData['judul_buku'] ?? '';
$tanggal_meminjam = $formData['tanggal_meminjam'] ?? date(Y-m-d);
$tanggal_kembali = $formData['tanggal_kembali'] ?? date(Y-m-d);

/**
 * Validation int value
 */
$jumlahFilter = filter_var($id_peminjaman, FILTER_VALIDATE_INT);

/**
 * METHOD OK
 * Validation OK
 * Check if data is exist
 */
try{
    $queryCheck = "SELECT * FROM peminjaman where id_peminjaman = :id_peminjaman";
    $statement = $connection->prepare($queryCheck);
    $statement->bindValue(':id_peminjaman', $id_peminjaman);
    $statement->execute();
    $row = $statement->rowCount();
    /**
     * Jika data tidak ditemukan
     * rowcount == 0
     */
    if($row === 0){
        $reply['error'] = 'Data tidak ditemukan ID PEMINJAMAN '.$id_peminjaman;
        echo json_encode($reply);
        http_response_code(400);
        exit(0);
    }
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}

/**
 * Prepare query
 */
try{
    $fields = [];
    $query = "UPDATE peminjaman SET id_pelanggan = :id_pelanggan, isbn = :isbn, judul_buku = :judul_buku, tanggal_meminjam = :tanggal_meminjam, tanggal_kembali = :tanggal_kembali
WHERE id_peminjaman = :id_peminjaman";
    $statement = $connection->prepare($query);
    /**
     * Bind params
     */
    $statement->bindValue(":id_peminjaman", $id_peminjaman, PDO::PARAM_INT);
    $statement->bindValue(":id_pelanggan", $id_pelanggan, PDO::PARAM_INT);
    $statement->bindValue(":isbn", $isbn, PDO::PARAM_INT);
    $statement->bindValue(":judul_buku", $judul_buku);
    $statement->bindValue(":tanggal_meminjam", $tanggal_meminjam);
    $statement->bindValue(":tanggal_kembali", $tanggal_kembali);
    /**
     * Execute query
     */
    $isOk = $statement->execute();
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}
/**
 * If not OK, add error info
 * HTTP Status code 400: Bad request
 * @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#client_error_responses
 */
if(!$isOk){
    $reply['error'] = $statement->errorInfo();
    http_response_code(400);
}

/*
 * Get data
 */
$stmSelect = $connection->prepare("SELECT * FROM peminjaman where id_peminjaman = :id_peminjaman");
$stmSelect->bindValue(':id_peminjaman', $id_peminjaman);
$stmSelect->execute();
$dataBuku = $stmSelect->fetch(PDO::FETCH_ASSOC);

/**
 * Show output to client
 */
$reply['status'] = $isOk;
echo json_encode($reply);