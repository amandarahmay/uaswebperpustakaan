<?php
include '../koneksi.php';

if($_SERVER['REQUEST_METHOD'] !== 'DELETE'){
    http_response_code(400);
    $reply['error'] = 'DELETE method required';
    echo json_encode($reply);
    exit();
}

/**
 * Get input data from RAW data
 */
$data = file_get_contents('php://input');
$res = [];
parse_str($data, $res);
$id_peminjaman = $res['id_peminjaman'] ?? '';

try{
    $queryCheck = "SELECT * FROM peminjaman where id_peminjaman = :id_peminjaman";
    $statement = $connection->prepare($queryCheck);
    $statement->bindValue(':id_peminjaman', $id_peminjaman);
    $statement->execute();
    $row = $statement->rowCount();
    /**
     * Jika data tidak ditemukan
     * rowcount == 0
     */
    if($row === 0){
        $reply['error'] = 'Data tidak ditemukan ID PEMINJAMAN'.$id_peminjaman;
        echo json_encode($reply);
        http_response_code(400);
        exit(0);
    }
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}

/**
 * Hapus data
 */
try{
    $queryCheck = "DELETE FROM peminjaman where id_peminjaman = :id_peminjaman";
    $statement = $connection->prepare($queryCheck);
    $statement->bindValue(':id_peminjaman', $id_peminjaman);
    $statement->execute();
}catch (Exception $exception){
    $reply['error'] = $exception->getMessage();
    echo json_encode($reply);
    http_response_code(400);
    exit(0);
}

/*
 * Send output
 */
$reply['status'] = true;
echo json_encode($reply);