<?php   
include '../koneksi.php';
 //logout.php  
 session_start();  
 session_destroy();  
 header("location:pdo_login.php");  
 ?> 